import datetime
import threading
import tkinter as tk
from tkinter import scrolledtext
from zoneinfo import ZoneInfo
import requests
import json
import os
from google.oauth2 import service_account
from googleapiclient.discovery import build

# ── CONFIG ────────────────────────────────────────────────────────────────────
SERVICE_ACCOUNT_FILE = 'service_account.json'
SCOPES               = ['https://www.googleapis.com/auth/calendar.readonly']
CALENDAR_ID          = 'sfreeman.1.sf@gmail.com'   # <── your Gmail address
YOUR_TIMEZONE        = 'America/New_York'
OLLAMA_URL           = 'http://localhost:11434/api/generate'
OLLAMA_MODEL         = 'llama3'                 # change to your model name
MEMORY_FILE          = 'assistant_memory.json'  # saved in same folder
MAX_MEMORY_MESSAGES  = 40                       # how many past messages to remember
# ─────────────────────────────────────────────────────────────────────────────

# ── Colors ────────────────────────────────────────────────────────────────────
BG_DARK     = "#0f0f1a"
BG_PANEL    = "#16162a"
BG_INPUT    = "#1e1e35"
ACCENT      = "#7c6af7"
ACCENT2     = "#a78bfa"
USER_COLOR  = "#e2e8f0"
BOT_COLOR   = "#a78bfa"
TIME_COLOR  = "#4a4a6a"
EVENT_COLOR = "#34d399"
BTN_HOVER   = "#6c5ce7"
TEXT_MAIN   = "#e2e8f0"
TEXT_DIM    = "#6b7280"
MEMORY_COLOR = "#fbbf24"   # gold — for memory notifications
# ─────────────────────────────────────────────────────────────────────────────


# ── MEMORY FUNCTIONS ──────────────────────────────────────────────────────────
def load_memory():
    """Load conversation history from disk."""
    if os.path.exists(MEMORY_FILE):
        try:
            with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return []
    return []


def save_memory(memory):
    """Save conversation history to disk."""
    # Keep only the most recent MAX_MEMORY_MESSAGES to avoid the file growing forever
    trimmed = memory[-MAX_MEMORY_MESSAGES:]
    try:
        with open(MEMORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(trimmed, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"Memory save error: {e}")


def format_memory_for_prompt(memory):
    """Turn saved memory into a readable summary for the LLM."""
    if not memory:
        return "No previous conversations."
    lines = []
    for entry in memory[-20:]:   # use last 20 for prompt context
        role = entry.get('role', 'unknown')
        text = entry.get('text', '')
        date = entry.get('date', '')
        if role == 'user':
            lines.append(f"Stacey ({date}): {text}")
        else:
            lines.append(f"Assistant ({date}): {text}")
    return "\n".join(lines)
# ─────────────────────────────────────────────────────────────────────────────


def get_calendar_service():
    creds = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    return build('calendar', 'v3', credentials=creds)


def fetch_upcoming_events(service, max_results=10):
    tz  = ZoneInfo(YOUR_TIMEZONE)
    now = datetime.datetime.now(tz=tz)
    result = service.events().list(
        calendarId=CALENDAR_ID,
        timeMin=now.isoformat(),
        maxResults=max_results,
        singleEvents=True,
        orderBy='startTime'
    ).execute()
    return result.get('items', [])


def format_events_for_display(events):
    if not events:
        return "No upcoming events found."
    tz = ZoneInfo(YOUR_TIMEZONE)
    lines = []
    for e in events:
        start_raw = e.get('start', {})
        start_str = start_raw.get('dateTime') or start_raw.get('date', 'Unknown')
        if 'T' in start_str:
            try:
                dt = datetime.datetime.fromisoformat(start_str)
                start_str = dt.astimezone(tz).strftime('%a %b %d  %I:%M %p ET')
            except Exception:
                pass
        title   = e.get('summary', 'Untitled event')
        loc     = e.get('location', '')
        loc_str = f"  📍 {loc}" if loc else ""
        lines.append(f"  🗓  {start_str}  —  {title}{loc_str}")
    return "\n".join(lines)


def ask_ollama(prompt):
    payload = {"model": OLLAMA_MODEL, "prompt": prompt, "stream": False}
    try:
        resp = requests.post(OLLAMA_URL, json=payload, timeout=120)
        resp.raise_for_status()
        return resp.json().get('response', '').strip()
    except requests.exceptions.ConnectionError:
        return "❌  Cannot reach Ollama. Make sure `ollama serve` is running."
    except Exception as exc:
        return f"❌  Error: {exc}"


class AssistantApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("✨ Stacey's AI Assistant")
        self.geometry("820x700")
        self.configure(bg=BG_DARK)
        self.resizable(True, True)
        self.minsize(600, 500)

        self.events     = []
        self.events_txt = "Loading calendar…"
        self.service    = None

        # Load memory from disk on startup
        self.memory = load_memory()
        self.session_history = []   # just this session's exchanges

        self._build_ui()
        self._load_calendar()

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        # Header
        header = tk.Frame(self, bg=ACCENT, height=56)
        header.pack(fill=tk.X)
        header.pack_propagate(False)

        tk.Label(header, text="✨  Stacey's AI Assistant",
                 bg=ACCENT, fg="white",
                 font=("Georgia", 16, "bold")).pack(side=tk.LEFT, padx=18, pady=12)

        self.status_lbl = tk.Label(header, text="● connecting…",
                                   bg=ACCENT, fg="#d4c5ff",
                                   font=("Consolas", 9))
        self.status_lbl.pack(side=tk.RIGHT, padx=18)

        # Memory indicator in header
        mem_count = len(self.memory)
        self.mem_lbl = tk.Label(header,
                                text=f"🧠 {mem_count} memories",
                                bg=ACCENT, fg=MEMORY_COLOR,
                                font=("Consolas", 9))
        self.mem_lbl.pack(side=tk.RIGHT, padx=12)

        # Sidebar
        sidebar = tk.Frame(self, bg=BG_PANEL, width=230)
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)

        tk.Label(sidebar, text="UPCOMING EVENTS",
                 bg=BG_PANEL, fg=ACCENT2,
                 font=("Consolas", 8, "bold")).pack(anchor="w", padx=14, pady=(14, 4))

        self.cal_text = tk.Text(sidebar, bg=BG_PANEL, fg=EVENT_COLOR,
                                font=("Consolas", 9), wrap=tk.WORD,
                                relief=tk.FLAT, bd=0,
                                state=tk.DISABLED, cursor="arrow",
                                selectbackground=BG_PANEL)
        self.cal_text.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 4))

        tk.Button(sidebar, text="⟳  Refresh Calendar",
                  bg=BG_INPUT, fg=ACCENT2,
                  font=("Consolas", 9), relief=tk.FLAT,
                  activebackground=BTN_HOVER, activeforeground="white",
                  cursor="hand2", command=self._load_calendar
                  ).pack(fill=tk.X, padx=8, pady=(0, 4))

        tk.Button(sidebar, text="🧠  View Memory Log",
                  bg=BG_INPUT, fg=MEMORY_COLOR,
                  font=("Consolas", 9), relief=tk.FLAT,
                  activebackground=BTN_HOVER, activeforeground="white",
                  cursor="hand2", command=self._show_memory_window
                  ).pack(fill=tk.X, padx=8, pady=(0, 4))

        tk.Button(sidebar, text="🗑  Clear Memory",
                  bg=BG_INPUT, fg="#f87171",
                  font=("Consolas", 9), relief=tk.FLAT,
                  activebackground="#7f1d1d", activeforeground="white",
                  cursor="hand2", command=self._clear_memory
                  ).pack(fill=tk.X, padx=8, pady=(0, 12))

        # Chat area
        chat_frame = tk.Frame(self, bg=BG_DARK)
        chat_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.chat_display = scrolledtext.ScrolledText(
            chat_frame, bg=BG_DARK, fg=TEXT_MAIN,
            font=("Consolas", 10), wrap=tk.WORD,
            relief=tk.FLAT, bd=0, state=tk.DISABLED,
            padx=12, pady=12,
            selectbackground=ACCENT)
        self.chat_display.pack(fill=tk.BOTH, expand=True, padx=4, pady=(4, 0))

        self.chat_display.tag_config("user",      foreground=USER_COLOR, font=("Consolas", 10, "bold"))
        self.chat_display.tag_config("assistant", foreground=BOT_COLOR,  font=("Consolas", 10))
        self.chat_display.tag_config("timestamp", foreground=TIME_COLOR, font=("Consolas", 8))
        self.chat_display.tag_config("system",    foreground=TEXT_DIM,   font=("Consolas", 9, "italic"))
        self.chat_display.tag_config("thinking",  foreground=ACCENT,     font=("Consolas", 9, "italic"))
        self.chat_display.tag_config("memory",    foreground=MEMORY_COLOR, font=("Consolas", 9, "italic"))

        # Input row
        input_frame = tk.Frame(chat_frame, bg=BG_INPUT, pady=8)
        input_frame.pack(fill=tk.X, padx=4, pady=6)

        self.input_box = tk.Text(input_frame, bg=BG_INPUT, fg=TEXT_MAIN,
                                 font=("Consolas", 11), height=2,
                                 relief=tk.FLAT, bd=0,
                                 insertbackground=ACCENT2,
                                 wrap=tk.WORD)
        self.input_box.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(12, 6), pady=4)
        self.input_box.bind("<Return>",       self._on_enter)
        self.input_box.bind("<Shift-Return>", lambda e: None)

        tk.Button(input_frame, text="Send  ➤",
                  bg=ACCENT, fg="white",
                  font=("Consolas", 10, "bold"),
                  relief=tk.FLAT, padx=14,
                  activebackground=BTN_HOVER, activeforeground="white",
                  cursor="hand2", command=self._send_message
                  ).pack(side=tk.RIGHT, padx=(0, 10))

        tk.Label(chat_frame,
                 text="Enter to send  •  Shift+Enter for new line",
                 bg=BG_DARK, fg=TIME_COLOR,
                 font=("Consolas", 8)).pack(anchor="e", padx=8)

    # ── CALENDAR ──────────────────────────────────────────────────────────────
    def _load_calendar(self):
        self._set_cal_text("Loading…")
        self._set_status("● connecting…", "#d4c5ff")
        threading.Thread(target=self._calendar_thread, daemon=True).start()

    def _calendar_thread(self):
        try:
            self.service    = get_calendar_service()
            self.events     = fetch_upcoming_events(self.service)
            self.events_txt = format_events_for_display(self.events)
            self.after(0, lambda: self._set_cal_text(self.events_txt))
            self.after(0, lambda: self._set_status("● calendar connected", "#86efac"))
            self.after(0, self._show_welcome)
        except Exception as exc:
            msg = f"Calendar error:\n{exc}"
            self.after(0, lambda: self._set_cal_text(msg))
            self.after(0, lambda: self._set_status("● calendar error", "#fca5a5"))

    def _show_welcome(self):
        tz      = ZoneInfo(YOUR_TIMEZONE)
        now_str = datetime.datetime.now(tz=tz).strftime('%A, %B %d  %I:%M %p ET')
        self._append_chat(f"📅  {now_str}\n", "timestamp")

        if self.memory:
            last = self.memory[-1]
            last_date = last.get('date', 'previously')
            self._append_chat(
                f"🧠  I remember our last conversation from {last_date}. "
                f"I have {len(self.memory)} memories stored.\n",
                "memory")

        self._append_chat(
            "Hi Stacey! 👋  I'm connected to your Google Calendar and ready to help.\n"
            "Ask me anything about your schedule, research, or just chat!\n",
            "assistant")

    # ── CHAT & MEMORY ─────────────────────────────────────────────────────────
    def _on_enter(self, event):
        if not event.state & 0x1:
            self._send_message()
            return "break"

    def _send_message(self):
        msg = self.input_box.get("1.0", tk.END).strip()
        if not msg:
            return
        self.input_box.delete("1.0", tk.END)

        tz  = ZoneInfo(YOUR_TIMEZONE)
        now = datetime.datetime.now(tz=tz)
        ts  = now.strftime('%I:%M %p')
        date_str = now.strftime('%Y-%m-%d %I:%M %p ET')

        self._append_chat(f"\n[{ts}] You\n", "timestamp")
        self._append_chat(f"{msg}\n", "user")
        self._append_chat("Assistant is thinking…\n", "thinking")

        # Save user message to memory
        self.memory.append({"role": "user", "text": msg, "date": date_str})
        self.session_history.append(f"Stacey: {msg}")

        threading.Thread(target=self._ollama_thread, args=(msg,), daemon=True).start()

    def _ollama_thread(self, user_msg):
        tz      = ZoneInfo(YOUR_TIMEZONE)
        now_str = datetime.datetime.now(tz=tz).strftime('%A, %B %d %Y  %I:%M %p ET')

        memory_context = format_memory_for_prompt(self.memory[:-1])  # exclude current msg

        system_ctx = (
            f"You are Stacey's personal AI assistant. "
            f"Current date/time: {now_str}.\n\n"
            f"Stacey's upcoming calendar events (Eastern Time):\n{self.events_txt}\n\n"
            f"MEMORY OF PAST CONVERSATIONS:\n{memory_context}\n\n"
            f"CURRENT SESSION:\n" + "\n".join(self.session_history) +
            "\n\nUse the memory above to give personalized, context-aware responses. "
            "Be concise, warm, and friendly. Remember details Stacey has shared before."
        )

        prompt = f"{system_ctx}\n\nAssistant:"
        reply  = ask_ollama(prompt)

        # Save assistant reply to memory
        date_str = datetime.datetime.now(tz=tz).strftime('%Y-%m-%d %I:%M %p ET')
        self.memory.append({"role": "assistant", "text": reply, "date": date_str})
        self.session_history.append(f"Assistant: {reply}")

        # Save to disk
        save_memory(self.memory)

        # Update memory count in header
        self.after(0, self._update_memory_label)
        self.after(0, lambda: self._replace_thinking(reply))

    def _replace_thinking(self, reply):
        self.chat_display.config(state=tk.NORMAL)
        content = self.chat_display.get("1.0", tk.END)
        thinking_line = "Assistant is thinking…\n"
        idx = content.rfind(thinking_line)
        if idx != -1:
            start = f"1.0 + {idx} chars"
            end   = f"1.0 + {idx + len(thinking_line)} chars"
            self.chat_display.delete(start, end)
        self.chat_display.config(state=tk.DISABLED)

        tz  = ZoneInfo(YOUR_TIMEZONE)
        ts  = datetime.datetime.now(tz=tz).strftime('%I:%M %p')
        self._append_chat(f"\n[{ts}] Assistant\n", "timestamp")
        self._append_chat(f"{reply}\n", "assistant")

    # ── MEMORY UI ─────────────────────────────────────────────────────────────
    def _update_memory_label(self):
        self.mem_lbl.config(text=f"🧠 {len(self.memory)} memories")

    def _show_memory_window(self):
        """Open a window showing the full memory log."""
        win = tk.Toplevel(self)
        win.title("🧠 Memory Log")
        win.geometry("600x500")
        win.configure(bg=BG_DARK)

        tk.Label(win, text="Conversation Memory Log",
                 bg=BG_DARK, fg=MEMORY_COLOR,
                 font=("Georgia", 13, "bold")).pack(pady=(12, 4))
        tk.Label(win, text=f"{len(self.memory)} memories stored in {MEMORY_FILE}",
                 bg=BG_DARK, fg=TEXT_DIM,
                 font=("Consolas", 9)).pack(pady=(0, 8))

        txt = scrolledtext.ScrolledText(win, bg=BG_PANEL, fg=TEXT_MAIN,
                                        font=("Consolas", 9), wrap=tk.WORD,
                                        relief=tk.FLAT, padx=10, pady=10)
        txt.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 12))

        if not self.memory:
            txt.insert(tk.END, "No memories yet. Start chatting!")
        else:
            for entry in self.memory:
                role = "🧑 Stacey" if entry['role'] == 'user' else "🤖 Assistant"
                date = entry.get('date', '')
                text = entry.get('text', '')
                txt.insert(tk.END, f"[{date}] {role}\n{text}\n\n")

        txt.config(state=tk.DISABLED)

    def _clear_memory(self):
        """Clear all memory after confirmation."""
        win = tk.Toplevel(self)
        win.title("Clear Memory?")
        win.geometry("340x160")
        win.configure(bg=BG_DARK)
        win.resizable(False, False)

        tk.Label(win, text="⚠️  Clear all memory?",
                 bg=BG_DARK, fg="#f87171",
                 font=("Georgia", 12, "bold")).pack(pady=(18, 6))
        tk.Label(win, text="This cannot be undone.",
                 bg=BG_DARK, fg=TEXT_DIM,
                 font=("Consolas", 9)).pack()

        btn_frame = tk.Frame(win, bg=BG_DARK)
        btn_frame.pack(pady=18)

        def confirm():
            self.memory = []
            save_memory(self.memory)
            self._update_memory_label()
            self._append_chat("🗑  Memory cleared.\n", "system")
            win.destroy()

        tk.Button(btn_frame, text="Yes, clear it",
                  bg="#7f1d1d", fg="white",
                  font=("Consolas", 10), relief=tk.FLAT, padx=12,
                  cursor="hand2", command=confirm).pack(side=tk.LEFT, padx=8)
        tk.Button(btn_frame, text="Cancel",
                  bg=BG_INPUT, fg=TEXT_MAIN,
                  font=("Consolas", 10), relief=tk.FLAT, padx=12,
                  cursor="hand2", command=win.destroy).pack(side=tk.LEFT, padx=8)

    # ── HELPERS ───────────────────────────────────────────────────────────────
    def _append_chat(self, text, tag="assistant"):
        self.chat_display.config(state=tk.NORMAL)
        self.chat_display.insert(tk.END, text, tag)
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)

    def _set_cal_text(self, text):
        self.cal_text.config(state=tk.NORMAL)
        self.cal_text.delete("1.0", tk.END)
        self.cal_text.insert(tk.END, text)
        self.cal_text.config(state=tk.DISABLED)

    def _set_status(self, text, color):
        self.status_lbl.config(text=text, fg=color)


if __name__ == '__main__':
    app = AssistantApp()
    app.mainloop()
